# Belly-Button-Biodiversity

Created an interactive dashboard to explore the Belly Button Biodiversity Data Set and completed an end-to-end
analysis. Technologies used: HTML/CSS/Bootstrap, JavaScript Library Plotly, Python and Flask

https://belly-button-biodiversity.herokuapp.com/